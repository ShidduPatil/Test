package DemoBlage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

public class DemoblazeSignUpTest {
    WebDriver driver;
   
    ExtentReports extent;
    ExtentTest test;

    @BeforeMethod
    public void Browser_setUp() {
    	 // Initialize ExtentReports
		
		/*ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("extentReport.html");
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);*/
    	System.setProperty("webdriver.chrome.driver","C:\\Selenium\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		// Instantiate a ChromeDriver class.
		WebDriver driver = new ChromeDriver();

		// Maximize the browser
		
         //driver.wait(1000);
		// Launch Website
		//Thread.sleep(1000);
		driver.get("https://www.demoblaze.com/index.html");
		driver.manage().window().maximize();
		 
}

    @Test
    public void testSignUp() {
    	 test = extent.createTest("Login Test");

         try {

        // Step 1: Click on the 'Sign Up' button to open the sign-up form
        WebElement signUpButton = driver.findElement(By.id("signin2"));  // Find the Sign Up button by ID
        signUpButton.click();

        // Step 2: Enter a username, password, and confirm the password
        WebElement usernameField = driver.findElement(By.id("sign-username"));  // Locate username input field by ID
        WebElement passwordField = driver.findElement(By.id("sign-password"));  // Locate password input field by ID
        
        // Replace these values with your test data
        String username = "newUser" + System.currentTimeMillis();  // Use dynamic username to avoid conflicts
        String password = "TestPassword123";  // Set a test password
        
        usernameField.sendKeys(username);  // Enter username
        passwordField.sendKeys(password);  // Enter password

        // Step 3: Click the 'Sign Up' button to submit the form
        WebElement signUpSubmitButton = driver.findElement(By.xpath("//button[text()='Sign up']"));
        signUpSubmitButton.click();

        // Step 4: Handle the alert that appears after signing up
        driver.switchTo().alert().accept();  // Accept the alert

        // Step 5: Verify that the user is signed up (check if the 'Log in' button is now visible)
        WebElement loginButton = driver.findElement(By.id("login2"));
        Assert.assertTrue(loginButton.isDisplayed(), "Sign up failed! 'Log in' button not found.");
         }
        // Optionally: You can log in immediately or verify the username on the main page
    catch (Exception e) {
        test.fail("Test failed with exception: " + e.getMessage());
    }

}


    @AfterMethod
    public void tearDown() {
        // Close the browser after the test is finished
        driver.quit();
    }
}

package DemoBlage;

import com.aventstack.extentreports.ExtentReports;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentTest;
import com.google.common.io.Files;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;

import org.apache.xmlbeans.impl.store.Path;
//import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
public class Login_DemoBlaze extends DemoblazeSignUpTest implements ITestListener {
	
	
	
	
	
	@BeforeMethod
    public void setUp() {
        // Initialize ExtentReports
		
		/*ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("extentReport.html");
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);*/
		 
		Browser_setUp();
        
    }

	 
	@Test(dataProvider = "loginData")
    public void testLogin(String username, String password, boolean expectedResult ) {
        test = extent.createTest("Login Test");

        try {

		WebElement Login = driver.findElement(By.id("login2"));
		 Login.click();
		  WebElement usernameField = driver.findElement(By.id("loginusername")); // Replace with actual locator
	        WebElement passwordField = driver.findElement(By.id("loginpassword")); // Replace with actual locator
	        WebElement loginButton = driver.findElement(By.xpath("(//*[@class=\"btn btn-primary\"])[3]"));
	        // Enter username and password
	     
	        usernameField.sendKeys(username);
	        passwordField.sendKeys(password);
	        
	        // Click the login button
	       
	        
	        loginButton.click();

	        // Validate the login result (you can improve this logic based on actual app behavior)
	        if (expectedResult) {
	            // Validate that login was successful (example)
	            WebElement loggedInElement = driver.findElement(By.id("profile")); // Replace with actual element for logged-in state
	            assert loggedInElement.isDisplayed();
	        } else {
	        	  WebElement loggedInUsername = driver.findElement(By.id("nameofuser"));
	              Assert.assertTrue(loggedInUsername.isDisplayed(), "Login failed!");
	        
	            test.pass("Login was successful.");
	        // Close the browser after each test
	        //driver.quit();
	        }
		 }
	        catch (Exception e) {
	            test.fail("Test failed with exception: " + e.getMessage());
	        }
	    
	    }

    @Override
    public void onTestStart(ITestResult result) {
        test = extent.createTest(result.getMethod().getMethodName());
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        test.pass("Test Passed");
    }

    @Override
    public void onTestFailure(ITestResult result) {
        test.fail(result.getThrowable());

        // Capture Screenshot on Failure
        File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        
             
             
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        test.skip("Test Skipped");
    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
        // Optional - can be used if you want specific behavior for tests that failed but are within the success percentage
    }

    @Override
    public void onStart(ITestContext context) {
        // Any global setup can be placed here
    }

    @Override
    public void onFinish(ITestContext context) {
        extent.flush();  // Save the report
        driver.quit();   // Close the browser
    }


	    @DataProvider(name = "loginData")
	    public Object[][] loginData() {
	        return new Object[][] {
	            { "testuser1", "password1", true },  // Valid login
	            { "testuser2", "wrongpassword", false }, // Invalid login
	            { "testuser3", "password3", true }  // Valid login
	        };
	    }

}
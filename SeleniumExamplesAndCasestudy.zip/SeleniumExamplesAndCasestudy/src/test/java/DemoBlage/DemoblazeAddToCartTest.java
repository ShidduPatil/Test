package DemoBlage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class DemoblazeAddToCartTest extends Login_DemoBlaze {
    WebDriver driver;

    @BeforeMethod
    public void setUp() {
    	 
    		
        // Set up WebDriver
        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");  // Set the correct path to your chromedriver
        driver = new ChromeDriver();
        driver.get("https://www.demoblaze.com");  // Navigate to Demoblaze website
    }

    @Test
    public void testAddToCart(String username, String password, boolean expectedResult) {
    	  test = extent.createTest("Login Test");

          try {

    	testLogin(password, password, expectedResult);
        // Step 1: Navigate to Phones category
        WebElement phonesCategory = driver.findElement(By.linkText("Phones"));
        phonesCategory.click();

        // Step 2: Select the first product (can be adjusted for any specific product)
        WebElement firstProduct = driver.findElement(By.xpath("//div[@class='card-block']//h4/a"));
        String productName = firstProduct.getText();
        firstProduct.click();

        // Step 3: Click on 'Add to cart' button
        WebElement addToCartButton = driver.findElement(By.xpath("//a[contains(text(), 'Add to cart')]"));
        addToCartButton.click();

        // Step 4: Handle the alert that appears (confirm the addition)
        driver.switchTo().alert().accept();  // Accept the alert after adding the item to the cart

        // Step 5: Go to the cart
        WebElement cartButton = driver.findElement(By.id("cartur"));
        cartButton.click();

        // Step 6: Verify that the correct product is in the cart
        WebElement cartProduct = driver.findElement(By.xpath("//tr/td[contains(text(), '" + productName + "')]"));
        Assert.assertTrue(cartProduct.isDisplayed(), "Product is not added to the cart!");
    } catch (Exception e) {
        test.fail("Test failed with exception: " + e.getMessage());
    }

}


    @AfterMethod
    public void tearDown() {
        // Close the browser after the test
        driver.quit();
    }
}
